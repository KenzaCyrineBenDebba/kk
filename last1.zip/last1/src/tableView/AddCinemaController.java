/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableView;

import helpers.DbConnect;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import models.Cinema;

/**
 * FXML Controller class
 *
 * @author kenza ben debba
 */
public class AddCinemaController implements Initializable {

    @FXML
    private TextField nameFId;
    @FXML
    private DatePicker date_diffusionFId;
    @FXML
    private TextField adresseFId;
    @FXML
    private TextField emailFId;
    
    String query= null;
    Connection connection= null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet= null;
    Cinema cinema = null;
    
    private boolean update;
    int cinemaId;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void save(MouseEvent event) {
        
         connection = DbConnect.getConnect();
        String name = nameFId.getText();
        String date_diffusion = String.valueOf(date_diffusionFId.getValue());
        String adresse = adresseFId.getText();
        String email = emailFId.getText();

        if (name.isEmpty() || date_diffusion.isEmpty() || adresse.isEmpty() || email.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please Fill All DATA");
            alert.showAndWait();

        } else {
            getQuery();
            insert();
            clean();

        }
        
    }

    @FXML
    private void clean() {
         nameFId.setText(null);
        date_diffusionFId.setValue(null);
        adresseFId.setText(null);
        emailFId.setText(null);
    }

    private void getQuery() {
        if(update ==false) {
       
            query = "INSERT INTO `cinema`(`name`, `date_diffusion`, `adresse`, `email`) VALUES (?,?,?,?)";
 
        }else {
            query = "UPDATE `cinema` SET "
                    + "`name`=?,"
                    + "`date_diffusion`=?,"
                    + "`adresse`=?,"
                    + "`email`= ? WHERE id = '"+cinemaId+"'";
        }
    }
    
    

    private void insert() {
          try {

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nameFId.getText());
            preparedStatement.setString(2, String.valueOf(date_diffusionFId.getValue()));
            preparedStatement.setString(3, adresseFId.getText());
            preparedStatement.setString(4, emailFId.getText());
            preparedStatement.execute();

        } catch (SQLException ex) {
            Logger.getLogger(AddCinemaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void setUpdate(boolean b) {
         this.update = b;
    }

    void setTextField(int id, String name, LocalDate toLocalDate, String adresse, String email) {
     cinemaId = id;
        nameFId.setText(name);
        date_diffusionFId.setValue(toLocalDate);
        adresseFId.setText(adresse);
        emailFId.setText(name);
    }
    
    
 
    
}
